#ifndef MYFUNC_H
#define MYFUNC_H

int myfunc(int b);

int fibonachi(int num);

#endif // MYFUNC_H
