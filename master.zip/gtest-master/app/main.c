#include <stdio.h>

#include "myfunc.h"

int main()
{
    printf("Hello World!\n");
    return myfunc(2);
}
